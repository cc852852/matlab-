function cal2(x)
%----------------------------mode indicator,character count
%indicator,encoding data,terminator
% x=input('please input','s');
a=size(x);
b=a(2);
i=1;
k=1;
A=['0' '1' '2' '3' '4' '5' '6' '7' '8' '9' 'A' 'B' 'C' 'D' 'E' 'F' 'G' 'H' 'I' 'J' 'K' 'L' 'M' 'N' 'O' 'P' 'Q' 'R' 'S' 'T' 'U' 'V' 'W' 'X' 'Y' 'Z' ' ' '$' '%' '*' '+' '-' '.' '/' ':'];
B=[0:1:44];

if mod(b,2)==0
    while i<=b
        j=1;
        while j<=45
            if x(i)==A(j)
                C=B(j);
            end
            if x(i+1)==A(j)
                D=B(j);
            end
            j=j+1;
        end
        E(k)=(45*C+D);
        k=k+1;
        i=i+2;
    end
    F2=dec2bin(E,11);
    F3=F2';
    f4=size(F3);
    ff=f4(1)*f4(2);
end

if b==1
    i=1;
    j=1;
    while j<=45
        if x(i)==A(j)
            C=B(j);
        end
        j=j+1;
    end
    
    F3=dec2bin(C,6);
    f4=size(F3);
    ff=f4(1)*f4(2);
    
elseif mod(b,2)==1
    while i<=b-1
        j=1;
        while j<=45
            if x(i)==A(j)
                C=B(j);
            end
            if x(i+1)==A(j)
                D=B(j);
            end
            j=j+1;
        end
        E(k)=(45*C+D);
        k=k+1;
        i=i+2;
    end
    for i=b
        j=1;
        while j<=45
            if x(b)==A(j)
                C=B(j);
            end
            j=j+1;
        end
    end
    f2=dec2bin(E,11);
    g2=dec2bin(C,6);
    ff2=f2';
    f=size(ff2);
    f3=f(1)*f(2);
    if f(2)==1
        ff2=ff2';
    end
    F3=[ff2(1:f3),g2];
    f4=size(F3);
    ff=f4(1)*f4(2);
end
%F2=encoding data
F1=['0' '0' '1' '0' ];
%F1=mode indicator for alphanumeric code
F4=dec2bin(b,9);
%F4=character count indicater for alphanumeric code
if f4(2)==1
    F3=F3';
    %F3=encoding data
end
terminator=['0' '0' '0' '0'];
F=[F1,F4, F3(1:ff),terminator];
%--------------------seperate to 8 bit each---------------------------
G=size(F);
g=1;
h=1;
i=1;
while mod(G(2),8)~=0
    j=repmat('0',1,i);
    F=[F1,F4, F3(1:ff),terminator,j];
    G=size(F);
    i=i+1;
end

while g<=G(2)
    H(h,1:8)=F(1,g:(g+7));
    g=g+8;
    h=h+1;
end
I=size(H);
if I(1)~=9
    H(((I(1))+1),1:8)=['1' '1' '1' '0' '1' '1' '0' '0'];
end
I=size(H);
if I(1)~=9
    H(((I(1))+1),1:8)=['0' '0' '0' '1' '0' '0' '0' '1'];
end
I=size(H);
if I(1)~=9
    H(((I(1))+1),1:8)=['1' '1' '1' '0' '1' '1' '0' '0'];
end
I=size(H);
if I(1)~=9
    H(((I(1))+1),1:8)=['0' '0' '0' '1' '0' '0' '0' '1'];
end
I=size(H);
if I(1)~=9
    H(((I(1))+1),1:8)=['1' '1' '1' '0' '1' '1' '0' '0'];
end
I=size(H);
if I(1)~=9
    H(((I(1))+1),1:8)=['0' '0' '0' '1' '0' '0' '0' '1'];
end
%--------------------------------correcting error----------
keep=bin2dec(H);
alpha2int_a=[0:255];
alpha2int_i=[1 2 4 8 16 32 64 128 29 58 116 232 205 135 19 38 76 152 45 90 180 117 234 201  143 3 6 12 24 48 96 192 157 39 78 156 37 74 148 53 106 212 181 119 238 193 159 35 70 140 5 10 20 40 80 160 93 186 105 210 185 111 222 161 95 190 97 194 153 47 94 188 101 202 137 15 30 60 120 240 253 231 211 187 107 214 177 127 254 225 223 163 91 182 113 226 217 175 67 134 17 34 68 136 13 26 52 104 208 189 103 206 129 31 62 124 248 237 199 147 59 118 236 197 151 51 102 204 133 23 46 92 184 109 218 169 79 158 33 66 132 21 42 84 168 77 154 41 82 164 85 170 73 146 57 114 228 213 183 115 230 209 191 99 198 145 63 126 252 229 215 179 123 246 241 255 227 219 171 75 150 49 98 196 149 55 110 220 165 87 174 65 130 25 50 100 200 141 7 14 28 56 112 224 221 167 83 166 81 162 89 178 121 242 249 239 195 155 43 86 172 69 138 9 18 36 72 144 61 122 244 245 247 243 251 235 203 139 11 22 44 88 176 125 250 233 207 131 27 54 108 216 173 71 142 1];
int2alpha_i=[1:255];
int2alpha_a=[0 1 25 2 50 26 198 3 223 51 238 27 104 199 75 4 100 224 14 52 141 239 129 28 193 105 248 200 8 76 113 5 138 101 47 225 36 15 33 53 147 142 218 240 18 130 69 29 181 194 125 106 39 249 185 201 154 9 120 77 228 114 166 6 191 139 98 102 221 48 253 226 152 37 179 16 145 34 136 54 208 148 206 143 150 219 189 241 210 19 92 131 56 70 64 30 66 182 163 195 72 126 110 107 58 40 84 250 133 186 61 202 94 155 159 10 21 121 43 78 212 229 172 115 243 167 87 7 112 192 247 140 128 99 13 103 74 222 237 49 197 254 24 227 165 153 119 38 184 180 124 17 68 146 217 35 32 137 46 55 63 209 91 149 188 207 205 144 135 151 178 220 252 190 97 242 86 211 171 20 42 93 158 132 60 57 83 71 109 65 162 31 45 67 216 183 123 164 118 196 23 73 236 127 12 111 246 108 161 59 82 41 157 85 170 251 96 134 177 187 204 62 90 203 89 95 176 156 169 160 81 11 245 22 235 122 117 44 215 79 174 213 233 230 231 173 232 116 214 244 234 168 80 88 175];

a=1;
while a<=9
    J=bin2dec(H);
    l=1;
    m=size(J);
    while l<=m(1)
        k=1;
        while k<=255
            if J(l)==int2alpha_i(k)
                ec_f1(l)=int2alpha_a(k);
            end
            k=k+1;
        end
        l=l+1;
    end
    ec_g1=[0 43 139 206 78 43 239 123 206 214 147 24 99 150 39 243 163 136];
    ec_g2=ec_g1+ec_f1(1);
    n=size(ec_g2);
    l=1;
    while l<=n(2)
        if ec_g2(l)>255
            ec_g2(l)=ec_g2(l)-255;
        end
        l=l+1;
    end
    l=1;
    while l<=n(2)
        k=1;
        while k<=256
            if ec_g2(l)==alpha2int_a(k);
                ec_g3(l)=alpha2int_i(k);
            end
            k=k+1;
        end
        l=l+1;
    end
    K=dec2bin(J,8);
    L=dec2bin(ec_g3);
    h=1;
    i=1;
    j=1;
    k=size(K);
    l=size(L);
    while i<=k(1)
        j=1;
        while j<=8
            if K(i,j)==L(i,j)
                M(i,j)='0';
            end
            if K(i,j)~=L(i,j)
                M(i,j)='1';
            end
            j=j+1;
        end
        i=i+1;
    end
    m=size(M);
    if l(1)>k(1)
        p=l(1)-k(1);
        q=1;
        while q<=p
            M((m(1)+q),1:8)=L((m(1)+q),1:8);
            q=q+1;
        end
    end
    ec_f2=bin2dec(M);
    r=size(ec_f2);
    s=1;
    t=1;
    while s<=(r(1)-1)
        ec_f3(s)=ec_f2(t+1);
        s=s+1;
        t=t+1;
    end
    clear H
    H=dec2bin(ec_f3);
    Remainder=ec_f3;
    clear ec_f3
    a=a+1;
    clear M L K J ec_f1 ec_g2 ec_g3 ec_f2 k l s t p q i j h n m
end
%-------------------------------------combine and arrange-------------
final=[keep' Remainder];
final_bin=dec2bin(final);
matrix(1:21,1:21)='0';
ee=final_bin';
matrix(21,21)=ee(1);
matrix(20,21)=ee(3);
matrix(19,21)=ee(5);
matrix(18,21)=ee(7);
matrix(17,21)=ee(9);
matrix(16,21)=ee(11);
matrix(15,21)=ee(13);
matrix(14,21)=ee(15);
matrix(13,21)=ee(17);
matrix(12,21)=ee(19);
matrix(11,21)=ee(21);
matrix(10,21)=ee(23);

matrix(21,20)=ee(2);
matrix(20,20)=ee(4);
matrix(19,20)=ee(6);
matrix(18,20)=ee(8);
matrix(17,20)=ee(10);
matrix(16,20)=ee(12);
matrix(15,20)=ee(14);
matrix(14,20)=ee(16);
matrix(13,20)=ee(18);
matrix(12,20)=ee(20);
matrix(11,20)=ee(22);
matrix(10,20)=ee(24);

matrix(21,19)=ee(47);
matrix(20,19)=ee(45);
matrix(19,19)=ee(43);
matrix(18,19)=ee(41);
matrix(17,19)=ee(39);
matrix(16,19)=ee(37);
matrix(15,19)=ee(35);
matrix(14,19)=ee(33);
matrix(13,19)=ee(31);
matrix(12,19)=ee(29);
matrix(11,19)=ee(27);
matrix(10,19)=ee(25);

matrix(21,18)=ee(48);
matrix(20,18)=ee(46);
matrix(19,18)=ee(44);
matrix(18,18)=ee(42);
matrix(17,18)=ee(40);
matrix(16,18)=ee(38);
matrix(15,18)=ee(36);
matrix(14,18)=ee(34);
matrix(13,18)=ee(32);
matrix(12,18)=ee(30);
matrix(11,18)=ee(28);
matrix(10,18)=ee(26);

matrix(21,17)=ee(49);
matrix(20,17)=ee(51);
matrix(19,17)=ee(53);
matrix(18,17)=ee(55);
matrix(17,17)=ee(57);
matrix(16,17)=ee(59);
matrix(15,17)=ee(61);
matrix(14,17)=ee(63);
matrix(13,17)=ee(65);
matrix(12,17)=ee(67);
matrix(11,17)=ee(69);
matrix(10,17)=ee(71);

matrix(21,16)=ee(50);
matrix(20,16)=ee(52);
matrix(19,16)=ee(54);
matrix(18,16)=ee(56);
matrix(17,16)=ee(58);
matrix(16,16)=ee(60);
matrix(15,16)=ee(62);
matrix(14,16)=ee(64);
matrix(13,16)=ee(66);
matrix(12,16)=ee(68);
matrix(11,16)=ee(70);
matrix(10,16)=ee(72);

matrix(21,15)=ee(95);
matrix(20,15)=ee(93);
matrix(19,15)=ee(91);
matrix(18,15)=ee(89);
matrix(17,15)=ee(87);
matrix(16,15)=ee(85);
matrix(15,15)=ee(83);
matrix(14,15)=ee(81);
matrix(13,15)=ee(79);
matrix(12,15)=ee(77);
matrix(11,15)=ee(75);
matrix(10,15)=ee(73);

matrix(21,14)=ee(96);
matrix(20,14)=ee(94);
matrix(19,14)=ee(92);
matrix(18,14)=ee(90);
matrix(17,14)=ee(88);
matrix(16,14)=ee(86);
matrix(15,14)=ee(84);
matrix(14,14)=ee(82);
matrix(13,14)=ee(80);
matrix(12,14)=ee(78);
matrix(11,14)=ee(76);
matrix(10,14)=ee(74);

matrix(21,13)=ee(97);
matrix(20,13)=ee(99);
matrix(19,13)=ee(101);
matrix(18,13)=ee(103);
matrix(17,13)=ee(105);;
matrix(16,13)=ee(107);
matrix(15,13)=ee(109);
matrix(14,13)=ee(111);
matrix(13,13)=ee(113);
matrix(12,13)=ee(115);
matrix(11,13)=ee(117);
matrix(10,13)=ee(119);
matrix(9,13)=ee(121);
matrix(8,13)=ee(123);
matrix(6,13)=ee(125);
matrix(5,13)=ee(127);
matrix(4,13)=ee(129);
matrix(3,13)=ee(131);
matrix(2,13)=ee(133);
matrix(1,13)=ee(135);

matrix(21,12)=ee(98);
matrix(20,12)=ee(100);
matrix(19,12)=ee(102);
matrix(18,12)=ee(104);
matrix(17,12)=ee(106);
matrix(16,12)=ee(108);
matrix(15,12)=ee(110);
matrix(14,12)=ee(112);
matrix(13,12)=ee(114);
matrix(12,12)=ee(116);
matrix(11,12)=ee(118);
matrix(10,12)=ee(120);
matrix(9,12)=ee(122);
matrix(8,12)=ee(124);
matrix(6,12)=ee(126);
matrix(5,12)=ee(128);
matrix(4,12)=ee(130);
matrix(3,12)=ee(132);
matrix(2,12)=ee(134);
matrix(1,12)=ee(136);

matrix(21,11)=ee(175);
matrix(20,11)=ee(173);
matrix(19,11)=ee(171);
matrix(18,11)=ee(169);
matrix(17,11)=ee(167);
matrix(16,11)=ee(165);
matrix(15,11)=ee(163);
matrix(14,11)=ee(161);
matrix(13,11)=ee(159);
matrix(12,11)=ee(157);
matrix(11,11)=ee(155);
matrix(10,11)=ee(153);
matrix(9,11)=ee(151);
matrix(8,11)=ee(149);
matrix(6,11)=ee(147);
matrix(5,11)=ee(145);
matrix(4,11)=ee(143);
matrix(3,11)=ee(141);
matrix(2,11)=ee(139);
matrix(1,11)=ee(137);

matrix(21,10)=ee(176);
matrix(20,10)=ee(174);
matrix(19,10)=ee(172);
matrix(18,10)=ee(170);
matrix(17,10)=ee(168);
matrix(16,10)=ee(166);
matrix(15,10)=ee(164);
matrix(14,10)=ee(162);
matrix(13,10)=ee(160);
matrix(12,10)=ee(158);
matrix(11,10)=ee(156);
matrix(10,10)=ee(154);
matrix(9,10)=ee(152);
matrix(8,10)=ee(150);
matrix(6,10)=ee(148);
matrix(5,10)=ee(146);
matrix(4,10)=ee(144);
matrix(3,10)=ee(142);
matrix(2,10)=ee(140);
matrix(1,10)=ee(138);

matrix(13,9)=ee(177);
matrix(12,9)=ee(179);
matrix(11,9)=ee(181);
matrix(10,9)=ee(183);

matrix(13,8)=ee(178);
matrix(12,8)=ee(180);
matrix(11,8)=ee(182);
matrix(10,8)=ee(184);

matrix(13,6)=ee(191);
matrix(12,6)=ee(189);
matrix(11,6)=ee(187);
matrix(10,6)=ee(185);

matrix(13,5)=ee(192);
matrix(12,5)=ee(190);
matrix(11,5)=ee(188);
matrix(10,5)=ee(186);

matrix(13,4)=ee(193);
matrix(12,4)=ee(195);
matrix(11,4)=ee(197);
matrix(10,4)=ee(199);

matrix(13,3)=ee(194);
matrix(12,3)=ee(196);
matrix(11,3)=ee(198);
matrix(10,3)=ee(200);

matrix(13,2)=ee(207);
matrix(12,2)=ee(205);
matrix(11,2)=ee(203);
matrix(10,2)=ee(201);

matrix(13,1)=ee(208);
matrix(12,1)=ee(206);
matrix(11,1)=ee(204);
matrix(10,1)=ee(202);
%----------------------------------------mask pattern-----------

z='0';
y='1';
for i=1:21
    for j=1:21
        sum=(i-1)+(j-1);
        if mod(sum,3)==0
            if matrix(i,j)==z
                matrix(i,j)='1';
           else
                matrix(i,j)='0';
           
            end
    end
    end
end
%---------------------------add finding pattern and format information
j=1;
for i=1:7
    matrix(i,j)='1';
end
for i=15:21
    matrix(i,j)='1';
end
j=2;
for i=2:6
    matrix(i,j)='0';
end
for i=16:20
    matrix(i,j)='0';
end
j=6;
for i=2:6
    matrix(i,j)='0';
end
for i=16:20
    matrix(i,j)='0';
end
j=7;
for i=1:7
    matrix(i,j)='1';
end
for i=15:21
    matrix(i,j)='1';
end
j=8;
for i=1:8
    matrix(i,j)='0';
end
for i=14:21
    matrix(i,j)='0';
end
j=14;
for i=1:8
    matrix(i,j)='0';
end
j=15;
for i=1:7
    matrix(i,j)='1';
end
j=16;
for i=2:6
    matrix(i,j)='0';
end
j=20;
for i=2:6
    matrix(i,j)='0';
end
j=21;
for i=1:7
    matrix(i,j)='1';
end
i=1;
for j=2:6
    matrix(i,j)='1';
end
for j=16:20
    matrix(i,j)='1';
end
i=2;
for j=3:5
    matrix(i,j)='0';
end
for j=17:19
    matrix(i,j)='0';
end
i=6;
for j=3:5
    matrix(i,j)='0';
end
for j=17:19
    matrix(i,j)='0';
end
 i=7;
for j=2:6
    matrix(i,j)='1';
end
for j=16:20
    matrix(i,j)='1';
end
i=8;
for j=1:7
    matrix(i,j)='0';
end
for j=15:21
    matrix(i,j)='0';
end
i=14;
for j=2:7
    matrix(i,j)='0';
end
i=15;
for j=2:6
    matrix(i,j)='1';
end
i=16;
for j=3:5
    matrix(i,j)='0';
end
i=20;
for j=3:5
    matrix(i,j)='0';
end
i=21;
for j=2:6
    matrix(i,j)='1';
end
for i=3:5
    for j=3:5
      matrix(i,j)='1';
    end
end
for i=17:19
    for j=3:5
      matrix(i,j)='1';
    end
end
for i=3:5
    for j=17:19
      matrix(i,j)='1';
    end
end
matrix(7,9:13)=['1' '0' '1' '0' '1'];
matrix(9:13,7)=['1' '0' '1' '0' '1'];
matrix(14,9)='1';
matrix(9,1:9)=['0' '0' '1' '1' '0' '0' '1' '1' '1'];
matrix(9,14:21)=['1' '1' '0' '1' '0' '0' '0' '0'];
matrix(1:8,9)=['0' '0' '0' '0' '1' '0' '1' '1'];
matrix(15:21,9)=['1' '0' '0' '1' '1' '0' '0'];
display (matrix)
%-----------------------------------plot---------------------
axis square
for j=1:21;
    for i=1:21;
    if matrix(i,j)=='1'
for m=(22-i):0.01:(22-i)+1
    line([j;j+1],[m;m],'Color','k')
end
    end
if matrix(i,j)=='0'
for m=(22-i):0.01:(22-i)+1
    line([j;j+1],[m;m],'Color','w')
end
end

    end
end
end
